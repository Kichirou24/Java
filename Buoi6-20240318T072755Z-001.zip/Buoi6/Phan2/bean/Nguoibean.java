package bean;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Nguoibean {
	private String hoTen;
	private boolean gioiTinh;
	private Date ngaySinh;
	
	public String getHoTen() {
		return hoTen;
	}
	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}
	public boolean isGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(boolean gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public Date getNgaySinh() {
		return ngaySinh;
	}
	public void setNgaySinh(Date ngaySinh) {
		this.ngaySinh = ngaySinh;
	}
	public Nguoibean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Nguoibean(String hoTen, boolean gioiTinh, Date ngaySinh) {
		super();
		this.hoTen = hoTen;
		this.gioiTinh = gioiTinh;
		this.ngaySinh = ngaySinh;
	}
	
	public int getTuoi() {
		SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
		String ns = date.format(ngaySinh); // ns = "10/11/2004"
		// int namsinh = Integer.parseInt(ns.split("[/]")[2]);
		String namsinh = ns.substring(6); // cat chuoi lay nam
		
		Date d = new Date(); // lay ngay gio hien tai
		String nht = date.format(d);
		// int namhientai = Integer.parseInt(nht.split("[/]")[2]);
		String namhientai = nht.substring(6);
		Integer tuoi = Integer.parseInt(namhientai) - Integer.parseInt(namsinh);
		
		return tuoi;
	}

	@Override
	public String toString() {
		SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
		String ngay = date.format(ngaySinh);
		return hoTen + ";" + (gioiTinh == true ? "Nam" : "Nu") + ";" + ngay + ";" + getTuoi();
	}
	
	
}
